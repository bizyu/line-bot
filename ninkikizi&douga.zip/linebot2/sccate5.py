import urllib.request
from bs4 import BeautifulSoup
import requests
import json

url = "https://gigazine.net/news/20181123-cut-price-iphone-xr-in-japan/"

def getNews(word):
	global result
	response = requests.get(url).text
	# BeautifulSoupの初期化
	soup = BeautifulSoup(response, 'html.parser')
	if word == "人気記事":
		tag = soup.find("div",{"id":"ranking-entry"})
		tag2 = tag.find_all("li")

		count = 0
		list = []
		result=[]
		contents=[]

		for tag in tag2:
			categgg=tag.find("a")
				# if tag.contents[0].find(word) > -1:
				# if tag.span.contents[0].find(word) > -1:
				# list.append(tag.span.contents[0])
			list.append(categgg.contents[0])
			list.append("https://gigazine.net" + categgg.get('href'))
			count += 1
			#１０記事まで
			if count == 10:
				break

	elif word == "人気動画":
		tag = soup.find("div",{"id":"yt-ranking"})
		tag2 = tag.find_all("div",{"class":"yt-ranking-link"})


    	# 該当記事カウント変数と結果格納リスト
		count = 0
		list = []
		result=[]
		contents=[]

		for tag in tag2:
			categgg=tag.find("a")
			list.append(categgg.contents[0])
			list.append(categgg.get('href'))
			count += 1
			if count == 6:
				break

	list=[str(i) for i in list]
	result = list
	result = '\n'.join(list)
	return result


#word = "人気記事"
#result = getNews(word)
#print(result)