import time
from selenium import webdriver

driver = webdriver.Chrome(executable_path = r'C:/Users/User/Desktop/chromedriver.exe')

driver.get("http://gigazine.net/")


#カテゴリ中のデスクトップの欄をクリック
elem_search_btn = driver.find_element_by_xpath('//*[@id="subNav"]/dl[2]/dd[1]/a/b')
elem_search_btn.click()
#次のページに移動
elem_search_btn = driver.find_element_by_xpath('//*[@id="nextpage"]/a')
elem_search_btn.click()
driver.close()

def getNews(word):
	global result
	for tag in tagtag:
		categgg=tag.find("div",{"class":"date"}).find("span",{"class":"catab"})
		# if tag.contents[0].find(word) > -1:
		# if tag.span.contents[0].find(word) > -1:
		# list.append(tag.span.contents[0])
		if categgg.contents[0].find(word) > -1:
			list.append(tag.span.contents[0])
			list.append(tag.a.get('href'))
			count += 1
		if count == 0:
			result.append("該当記事はありません") 

	list=[str(i) for i in list]
	result = '\n'.join(list)
	return result

 word="動画"
 result = getNews(word)
 print(result)